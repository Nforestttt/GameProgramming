﻿using UnityEngine;

public class PlanetClickController : MonoBehaviour
{
    public PlanetUIManager uiManager;
    public Camera mainCamera;
    public float zoomDistance = 3f;
    public float moveSpeed = 2f;

    private Transform targetPlanet;
    private bool isMoving = false;
    private Vector3 startPosition;
    private Quaternion startRotation;

    void Start()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        // 保存初始相机位置
        startPosition = mainCamera.transform.position;
        startRotation = mainCamera.transform.rotation;
    }

    void Update()
    {
        HandleClick();
        MoveCamera();
    }

    void HandleClick()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                Transform planet = hit.transform;

                targetPlanet = planet;
                isMoving = true;

                StartCoroutine(ClickFeedback(planet));

                ShowPlanetInfo(planet.name);
            }
        }
    }

    void MoveCamera()
    {
        if (!isMoving || targetPlanet == null) return;

        // 目标位置（星球前方一点）
        Vector3 direction = (mainCamera.transform.position - targetPlanet.position).normalized;
        Vector3 targetPos = targetPlanet.position + direction * zoomDistance;

        // 平滑移动
        mainCamera.transform.position = Vector3.Lerp(
            mainCamera.transform.position,
            targetPos,
            Time.deltaTime * moveSpeed
        );

        // 看向星球
        Quaternion lookRotation = Quaternion.LookRotation(targetPlanet.position - mainCamera.transform.position);
        mainCamera.transform.rotation = Quaternion.Slerp(
            mainCamera.transform.rotation,
            lookRotation,
            Time.deltaTime * moveSpeed
        );
    }

    System.Collections.IEnumerator ClickFeedback(Transform planet)
    {
        Vector3 originalScale = planet.localScale;

        Vector3 bigger = originalScale * 1.15f;

        float t = 0;

        // 放大
        while (t < 1)
        {
            t += Time.deltaTime * 8;
            planet.localScale = Vector3.Lerp(originalScale, bigger, t);
            yield return null;
        }

        t = 0;

        // 回弹
        while (t < 1)
        {
            t += Time.deltaTime * 6;
            planet.localScale = Vector3.Lerp(bigger, originalScale, t);
            yield return null;
        }
    }

    void ShowPlanetInfo(string name)
    {
        if (uiManager == null) return;

        switch (name)
        {
            case "Earth":
                uiManager.ShowInfo("Earth", "Our home planet. It has water, air, and life.");
                break;

            case "Moon":
                uiManager.ShowInfo("Moon", "Earth's natural satellite. It helps control tides.");
                break;

            case "sun":
                uiManager.ShowInfo("sun", "A giant star that gives Earth light and heat.");
                break;

            case "Comet":
                uiManager.ShowInfo("Comet", "A snowy space traveler that leaves a glowing tail.");
                break;

            default:
                uiManager.ShowInfo(name, "A mysterious object in space.");
                break;
        }

       
}

    public void ReturnToMainView()
    {
        targetPlanet = null;
        isMoving = false;

        StopAllCoroutines();

        StartCoroutine(ReturnCamera());
    }

    System.Collections.IEnumerator ReturnCamera()
    {
        Vector3 currentPos = mainCamera.transform.position;
        Quaternion currentRot = mainCamera.transform.rotation;

        float t = 0;

        while (t < 1)
        {
            t += Time.deltaTime * moveSpeed;

            mainCamera.transform.position = Vector3.Lerp(currentPos, startPosition, t);
            mainCamera.transform.rotation = Quaternion.Slerp(currentRot, startRotation, t);

            yield return null;
        }
    }
}