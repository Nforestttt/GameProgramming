using UnityEngine;
using TMPro;

public class PlanetUIManager : MonoBehaviour
{
    public GameObject panel;
    public TMP_Text nameText;
    public TMP_Text descText;

    void Start()
    {
        panel.SetActive(false);
    }

    public void ShowInfo(string planetName, string description)
    {
        panel.SetActive(true);
        nameText.text = planetName;
        descText.text = description;
    }

    public void HideInfo()
    {
        panel.SetActive(false);
    }
}